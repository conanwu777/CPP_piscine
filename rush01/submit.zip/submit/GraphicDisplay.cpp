#include "GraphicDisplay.hpp"
#include <iostream>
#define W 300
#define H 1200
#define STR mlx_string_put

GraphicDisplay* GraphicDisplay::inst;

extern "C"
{
# include "mlx.h"
}

void GraphicDisplay::StrtoWin(int x, int y, std::string str) {
	STR(GraphicDisplay::inst->mlx, GraphicDisplay::inst->win,
		x, y, 0xffffff, const_cast<char*>(str.c_str()));
}

void GraphicDisplay::putBar(int x, int y, int ind, float f) {
	for (int i = 0; i < static_cast<int>(f); i++)
	{
		mlx_pixel_put(GraphicDisplay::inst->mlx, GraphicDisplay::inst->win,
			x + ind, y + 120 - i, 0xffffff);
		mlx_pixel_put(GraphicDisplay::inst->mlx, GraphicDisplay::inst->win,
			x + ind + 1, y + 120 - i, 0xffffff);
	}
}

int refresh() {
	for (int y = 0; y < H; y++)
		for (int x = 0; x < W; x++)
			mlx_pixel_put(GraphicDisplay::inst->mlx,
				GraphicDisplay::inst->win, x, y, 0x738c9b);
	GraphicDisplay::inst->getHostname()->graphicDisplay(40, 40);
	GraphicDisplay::inst->getOsinfo()->graphicDisplay(40, 120);
	GraphicDisplay::inst->getDt()->graphicDisplay(40, 200);
	GraphicDisplay::inst->getCpu()->graphicDisplay(40, 260);
	GraphicDisplay::inst->getUsage()->graphicDisplay(40, 420);
	GraphicDisplay::inst->getRam()->graphicDisplay(40, 670);
	GraphicDisplay::inst->getNet()->graphicDisplay(40, 800);
	return 0;
}

int		k_control(int key)
{
	if (key == 53)
		exit(1);
	return (1);
}

GraphicDisplay::GraphicDisplay(std::vector<IMonitorModule*> info) : info(info){
	mlx = mlx_init();
	win = mlx_new_window(mlx, W, H, const_cast<char*>("ft_gkrellm"));
	mlx_key_hook(win, &k_control, (void*)0);
	mlx_loop_hook(mlx, &refresh, 0);
	GraphicDisplay::inst = this;
	mlx_loop(mlx);
}

GraphicDisplay::~GraphicDisplay(){}

IMonitorModule*	GraphicDisplay::getHostname() const {
	return (info.at(0));
}

IMonitorModule*	GraphicDisplay::getOsinfo() const {
	return (info.at(1));
}

IMonitorModule*	GraphicDisplay::getDt() const {
	return (info.at(2));
}

IMonitorModule*	GraphicDisplay::getCpu() const {
	return (info.at(3));
}

IMonitorModule*	GraphicDisplay::getUsage() const {
	return (info.at(4));
}

IMonitorModule*	GraphicDisplay::getRam() const {
	return (info.at(5));
}

IMonitorModule*	GraphicDisplay::getNet() const {
	return (info.at(6));
}
