#include "GraphicDisplay.hpp"

HostnameModule::HostnameModule(std::string const name) :
	IMonitorModule(), _stats(), _name(name), _size(2)
{
	char hn[256];
	char un[256];
	hn[255] = '\0';
	un[255] = '\0';
	gethostname(hn, 255);
	getlogin_r(un, 255);
	this->_stats.push_back(hn);
	this->_stats.push_back(un);
	return ;
}

HostnameModule::HostnameModule(HostnameModule const &other)
{
	*this = other;
	return;
}

HostnameModule	&HostnameModule::operator=(HostnameModule const &)
{
	return (*this);
}

HostnameModule::~HostnameModule()
{
	return ;
}

std::vector<std::string> const		&HostnameModule::getStats(void) const
{
	return (this->_stats);
}

std::string const					&HostnameModule::getName(void) const
{
	return (this->_name);
}

void								HostnameModule::update(void)
{
	return;
}

int const							&HostnameModule::getSize(void) const
{
	return (this->_size);
}

void	HostnameModule::graphicDisplay(int x, int y) {
	std::vector<std::string> stats
		= this->getStats();
	GraphicDisplay::StrtoWin(x, y, "Hostname:");
	for (unsigned int i = 0; i < stats.size(); i++)
	{
		GraphicDisplay::StrtoWin(x, y + 20 * (i + 1), stats.at(i));
	}
}
