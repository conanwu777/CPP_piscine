#include "GraphicDisplay.hpp"

int main(){
	std::string name = "info";
	HostnameModule hostname(name);
	OSInfoModule osinfo(name);
	DateTimeModule dt(name);
	CPUInfoModule cpu(name);
	CPUUsageModule usage(name);
	RAMUsageModule ram(name);
	NetworkUsageModule net(name);

	std::vector<IMonitorModule*> info;
	info.push_back(&hostname);
	info.push_back(&osinfo);
	info.push_back(&dt);
	info.push_back(&cpu);
	info.push_back(&usage);
	info.push_back(&ram);
	info.push_back(&net);

	GraphicDisplay g(info);
}
