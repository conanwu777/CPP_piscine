#include "RAMUsageModule.hpp"
#include "GraphicDisplay.hpp"

RAMUsageModule::RAMUsageModule(std::string const name) : 
	IMonitorModule(), _stats(), _name(name), _size(2)
{
	system("mkdir monitorFiles > /dev/null");
	this->update();
	return ;
}

RAMUsageModule::RAMUsageModule(RAMUsageModule const &other)
{
	*this = other;
	return;
}

RAMUsageModule	&RAMUsageModule::operator=(RAMUsageModule const &)
{
	return (*this);
}

RAMUsageModule::~RAMUsageModule()
{
	return ;
}

std::vector<std::string> const		&RAMUsageModule::getStats(void) const
{
	return (this->_stats);
}

std::string const					&RAMUsageModule::getName(void) const
{
	return (this->_name);
}

void								RAMUsageModule::update(void)
{
	system((RAMUsageModule::_getInfoSysCommand).c_str());
	this->addFileInfoToStats(this->readStatsFile());
	return;
}

int const							&RAMUsageModule::getSize(void) const
{
	return (this->_size);
}

const std::string					RAMUsageModule::readStatsFile(void) const
{
	std::ifstream file;
	file.open(RAMUsageModule::_monitorFilePath);
	std::string line = "";
	if (file.is_open())
	{
		std::getline(file, line);
		file.close();
	}
	else
	{
		line = "PhysMem: ERROR used (ERROR wired), ERROR unused.";
	}
	return line;
}

void								RAMUsageModule::addFileInfoToStats(std::string info)
{
	std::string token;
	size_t pos = info.find(": ") + 1;
	size_t end = info.find(" used");
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // used

	pos = info.find(", ", end) + 1;
	end = info.find(" unused", pos);
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // unused
}

const std::string RAMUsageModule::_monitorFilePath = "monitorFiles/ramUsage.monitor";
const std::string RAMUsageModule::_getInfoSysCommand = "top -l 1 | grep \"PhysMem:\" > " + RAMUsageModule::_monitorFilePath;

void	RAMUsageModule::graphicDisplay(int x, int y) {
	static int totalRAM = 0;
	this->update();
	std::vector<std::string> stats
		= this->getStats();
	if (totalRAM == 0)
		totalRAM = stoi(stats.at(stats.size() - 1)) + stoi(stats.at(stats.size() - 2));
	std::cout << totalRAM << std::endl;
	GraphicDisplay::StrtoWin(x, y, "RAM usage:");
	for (int i = (stats.size() > 130 ? stats.size() - 130 : 0); i < static_cast<int>(stats.size()); i += 2)
		GraphicDisplay::putBar(x, y - 20, (stats.size() - i) / 3 * 2, stof(stats.at(i)) / totalRAM);
		// GraphicDisplay::putBar(x, y - 20, stats.size() - i, stof(stats.at(i)));
}
