#ifndef GRAPHICDISPLAY_HPP
# define GRAPHICDISPLAY_HPP
# include <vector>
# include <string>
# include "IMonitorDisplay.hpp"
# include "OSInfoModule.hpp"
# include "HostnameModule.hpp"
# include "DateTimeModule.hpp"
# include "CPUUsageModule.hpp"
# include "CPUInfoModule.hpp"
# include "RAMUsageModule.hpp"
# include "NetworkUsageModule.hpp"

class OSInfoModule;

class GraphicDisplay : public IMonitorDisplay
{
	private:
		GraphicDisplay(GraphicDisplay const &other);
		GraphicDisplay	&operator=(GraphicDisplay const &other);
		GraphicDisplay();
		std::vector<IMonitorModule*> info;
	public:
		GraphicDisplay(std::vector<IMonitorModule*> info);
		virtual ~GraphicDisplay(void);
		static void StrtoWin(int x, int y, std::string str);
		static void putBar(int x, int y, int ind, float f);

		void	*mlx;
		void	*win;
		IMonitorModule*	getHostname() const;
		IMonitorModule*	getOsinfo() const;
		IMonitorModule*	getDt() const;
		IMonitorModule*	getCpu() const;
		IMonitorModule*	getUsage() const;
		IMonitorModule*	getRam() const;
		IMonitorModule*	getNet() const;
		static GraphicDisplay* inst;
};

#endif
