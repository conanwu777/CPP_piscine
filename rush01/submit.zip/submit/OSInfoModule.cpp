#include "OSInfoModule.hpp"

OSInfoModule::OSInfoModule(std::string const name) :
	IMonitorModule(), _stats(), _name(name), _size(2)
{
	// https://stackoverflow.com/questions/15580179/how-do-i-find-the-name-of-an-operating-system
    struct utsname uts;
    uname(&uts);

	this->_stats.push_back(uts.sysname);
	this->_stats.push_back(uts.release);
	return ;
}

OSInfoModule::OSInfoModule(OSInfoModule const &other)
{
	*this = other;
	return;
}

OSInfoModule	&OSInfoModule::operator=(OSInfoModule const &)
{
	return (*this);
}

OSInfoModule::~OSInfoModule()
{
	return ;
}

std::vector<std::string> const		&OSInfoModule::getStats(void) const
{
	return (this->_stats);
}

std::string const					&OSInfoModule::getName(void) const
{
	return (this->_name);
}

void								OSInfoModule::update(void)
{
	return;
}

int const							&OSInfoModule::getSize(void) const
{
	return (this->_size);
}

void	OSInfoModule::graphicDisplay(int x, int y) {
	std::vector<std::string> stats
		= this->getStats();
	GraphicDisplay::StrtoWin(x, y, "OS info:");
	for (unsigned int i = 0; i < stats.size(); i++)
	{
		GraphicDisplay::StrtoWin(x, y + 20 * (i + 1), stats.at(i));
	}
}
