#ifndef IMonitorDisplay_HPP
# define IMonitorDisplay_HPP
# include <vector>
# include <string>

class IMonitorDisplay
{};

#endif
