#include "CPUUsageModule.hpp"
#include "GraphicDisplay.hpp"
#include <algorithm>

CPUUsageModule::CPUUsageModule(std::string const name) : 
	IMonitorModule(), _stats(), _name(name), _size(3)
{
	system("mkdir monitorFiles > /dev/null");
	this->update();
	return ;
}

CPUUsageModule::CPUUsageModule(CPUUsageModule const &other)
{
	*this = other;
	return;
}

CPUUsageModule	&CPUUsageModule::operator=(CPUUsageModule const &)
{
	return (*this);
}

CPUUsageModule::~CPUUsageModule()
{
	return ;
}

std::vector<std::string> const		&CPUUsageModule::getStats(void) const
{
	return (this->_stats);
}

std::string const					&CPUUsageModule::getName(void) const
{
	return (this->_name);
}

void								CPUUsageModule::update(void)
{
	system((CPUUsageModule::_getInfoSysCommand).c_str());
	this->addFileInfoToStats(this->readStatsFile());
	return;
}

int const							&CPUUsageModule::getSize(void) const
{
	return (this->_size);
}

const std::string					CPUUsageModule::readStatsFile(void) const
{
	std::ifstream file;
	file.open(CPUUsageModule::_monitorFilePath);
	std::string line = "";
	if (file.is_open())
	{
		std::getline(file, line);
		file.close();
	}
	else
	{
		line = "User: ERROR | Sys: ERROR | Idle: ERROR";
	}
	return line;
}

void								CPUUsageModule::addFileInfoToStats(std::string const info)
{
	std::string token;
	size_t pos = info.find(": ") + 1;
	size_t end = info.find("%") - 1;
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // user

	pos = info.find(", ", end) + 1;
	end = info.find("%", pos) - 1;
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // sys

	pos = info.find(", ", end) + 1;
	end = info.find("%", pos) - 1;
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // idle
}

void	CPUUsageModule::graphicDisplay(int x, int y) {
	this->update();
	std::vector<std::string> stats
		= this->getStats();
	GraphicDisplay::StrtoWin(x, y, "CPU usage:");
	for (int i = (stats.size() > 201 ? stats.size() - 201 : 0); i < static_cast<int>(stats.size()); i += 3)
		GraphicDisplay::putBar(x, y - 20, stats.size() - i, stof(stats.at(i)));
	GraphicDisplay::StrtoWin(x, y + 100, "User:      %");
	GraphicDisplay::StrtoWin(x + 48, y + 100, stats.at(stats.size() - 3));
	for (int i = (stats.size() > 200 ? stats.size() - 200 : 1); i < static_cast<int>(stats.size()); i += 3)
		GraphicDisplay::putBar(x, y + 100, stats.size() - i, stof(stats.at(i)));
	GraphicDisplay::StrtoWin(x, y + 220, "System:      %");
	GraphicDisplay::StrtoWin(x + 70, y + 220, stats.at(stats.size() - 2));
}

const std::string CPUUsageModule::_monitorFilePath = "monitorFiles/cpuUsage.monitor";
const std::string CPUUsageModule::_getInfoSysCommand = "top -l 1 | grep \"CPU usage:\" > " + CPUUsageModule::_monitorFilePath;
