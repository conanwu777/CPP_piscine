#include "NetworkUsageModule.hpp"
#include "GraphicDisplay.hpp"

NetworkUsageModule::NetworkUsageModule(std::string const name) : 
	IMonitorModule(), _stats(), _name(name), _size(4)
{
	system("mkdir monitorFiles > /dev/null");
	this->update();
	return ;
}

NetworkUsageModule::NetworkUsageModule(NetworkUsageModule const &other)
{
	*this = other;
	return;
}

NetworkUsageModule	&NetworkUsageModule::operator=(NetworkUsageModule const &)
{
	return (*this);
}

NetworkUsageModule::~NetworkUsageModule()
{
	return ;
}

std::vector<std::string> const		&NetworkUsageModule::getStats(void) const
{
	return (this->_stats);
}

std::string const					&NetworkUsageModule::getName(void) const
{
	return (this->_name);
}

void								NetworkUsageModule::update(void)
{
	system((NetworkUsageModule::_getInfoSysCommand).c_str());
	this->addFileInfoToStats(this->readStatsFile());
	return;
}

int const							&NetworkUsageModule::getSize(void) const
{
	return (this->_size);
}

const std::string					NetworkUsageModule::readStatsFile(void) const
{
	std::ifstream file;
	file.open(NetworkUsageModule::_monitorFilePath);
	std::string line = "";
	if (file.is_open())
	{
		std::getline(file, line);
		file.close();
	}
	else
	{
		line = "User: ERROR | Sys: ERROR | Idle: ERROR";
	}
	return line;
}

void	NetworkUsageModule::addFileInfoToStats(std::string const info)
{
	std::string token;
	size_t pos = info.find("packets: ") + 9;
	size_t end = info.find("/") - 1;
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // packets in

	pos = info.find("/", end) + 1;
	end = info.find(" in", pos);
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // in size

	pos = info.find(", ", end) + 2;
	end = info.find("/", pos) - 1;
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // packets out

	pos = info.find("/", end) + 1;
	end = info.find(" out", pos);
	token = info.substr(pos, end - pos);
	this->_stats.push_back(token); // out size
}

const std::string NetworkUsageModule::_monitorFilePath = "monitorFiles/netUsage.monitor";
const std::string NetworkUsageModule::_getInfoSysCommand = "top -l 1 | grep \"Networks:\" > " + NetworkUsageModule::_monitorFilePath;

void	NetworkUsageModule::graphicDisplay(int x, int y){
	this->update();
	std::vector<std::string> stats
		= this->getStats();
	GraphicDisplay::StrtoWin(x, y, "Network Usage:");
	GraphicDisplay::StrtoWin(x, y + 20, stats.at(stats.size() - 4));
	GraphicDisplay::StrtoWin(x, y + 40, stats.at(stats.size() - 3));
	GraphicDisplay::StrtoWin(x, y + 60, stats.at(stats.size() - 2));
	GraphicDisplay::StrtoWin(x, y + 80, stats.at(stats.size() - 1));
}




